function CVI_guarda_coord_esferica()
{
    string nome_arquivo, nome_generico;
    ofstream cesf;

    nome_generico="cesfera";
    char num='z';
    if (n==1) num='1'; else if (n==2) num='2'; else if (n==3) num='3'; else if (n==4) num='4';
    else if (n==5) num='5'; else if (n==6) num='6';

    nome_arquivo = nome_generico + char(num)+".txt";
    cesf.open (nome_arquivo.c_str());

    for (int i=0; i<vertice_n; i++)
        cesf << phi[i] << " " << theta[i] << endl;

    cesf.close();
}