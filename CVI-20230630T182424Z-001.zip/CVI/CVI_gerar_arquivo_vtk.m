function CVI_gerar_arquivo_vtk;
{
    string nome_arquivo, nome_generico;
    cout << vertice_n << " n = " << n << endl;
    ofstream ico;

    nome_generico="delaunay";
    char num='z';
    if (n==1) num='1'; else if (n==2) num='2'; else if (n==3) num='3';
    else if (n==4) num='4'; else if (n==5) num='5'; else if (n==6) num='6';

    nome_arquivo = nome_generico + char(num)+".vtk";
    ico.open (nome_arquivo.c_str());
    // esta estrutura � montada para gerar um arquivo no formato vtk.
    // Este arquivo serve para gerar uma vizualiza��o no paraview.
    ico << "# vtk DataFile Version 3.0" << endl;
    ico << "Exemplo Icosaedro" << endl;
    ico << "ASCII" << endl;
    ico << "DATASET POLYDATA" << endl;
    ico << "POINTS " << vertice_n << " float" << endl;

    for (int i=0; i<vertice_n; i++)
        ico << x[i] << " " << y[i] << " " << z[i] << endl;

    ico << "POLYGONS " << face_n << " " << 4*face_n << endl;

    for (int i=0; i<face_n; i++)
        ico << 3 << " " << face[i][0] << " " << face[i][1] << " " << face[i][2] << endl;

    ico.close();
}
