function [x, y, z] = CVI_calculo_novos_vertices(int k)
{
     d1=0.0; d2=0.0; d3=0.0; x0=0.0; x1=0.0; x2=0.0;
     y_0=0.0; y_1=0.0; y_2=0.0; z0=0.0; z1=0.0; z2=0.0;
     // C�lculo da 2*norma do bissetor.
     d1 = sqrt( potenciaf( xant[faceant[k][0]] + xant[faceant[k][1]], 2) + potenciaf( yant[faceant[k][0]] + yant[faceant[k][1]], 2) + potenciaf( zant[faceant[k][0]] + zant[faceant[k][1]], 2) );
     d2 = sqrt( potenciaf( xant[faceant[k][1]] + xant[faceant[k][2]], 2) + potenciaf( yant[faceant[k][1]] + yant[faceant[k][2]], 2) + potenciaf( zant[faceant[k][1]] + zant[faceant[k][2]], 2) );
     d3 = sqrt( potenciaf( xant[faceant[k][0]] + xant[faceant[k][2]], 2) + potenciaf( yant[faceant[k][0]] + yant[faceant[k][2]], 2) + potenciaf( zant[faceant[k][0]] + zant[faceant[k][2]], 2) );
     // Coordenadas do 1� bissetor. S� ser� guardada depois que verificar que � �nica.
     x0 = (xant[faceant[k][0]] + xant[faceant[k][1]]) / d1;
     y_0= (yant[faceant[k][0]] + yant[faceant[k][1]]) / d1;
     z0 = (zant[faceant[k][0]] + zant[faceant[k][1]]) / d1;
     // Coordenadas do 2� bissetor. S� ser� guardada depois que verificar que � �nica.
     x1 = (xant[faceant[k][1]] + xant[faceant[k][2]]) / d2;
     y_1= (yant[faceant[k][1]] + yant[faceant[k][2]]) / d2;
     z1 = (zant[faceant[k][1]] + zant[faceant[k][2]]) / d2;
     // Coordenadas do 3� bissetor. S� ser� guardada depois que verificar que � �nica.
     x2 = (xant[faceant[k][0]] + xant[faceant[k][2]]) / d3;
     y_2= (yant[faceant[k][0]] + yant[faceant[k][2]]) / d3;
     z2 = (zant[faceant[k][0]] + zant[faceant[k][2]]) / d3;

     b1[k][0] = x0; b1[k][1] = y_0; b1[k][2] = z0;
     b2[k][0] = x1; b2[k][1] = y_1; b2[k][2] = z1;
     b3[k][0] = x2; b3[k][1] = y_2; b3[k][2] = z2;
     // A partir de agora, verificamos a unicidade de cada v�rtice novo.
     v0=0; v1=0; v2=0; vrepetido=0;

     v0 = contador_vertice; // Se o v�rtice novo n�o existe, ent�o
                            // ele recebe um novo �ndice, cc, ele
                            // guarda o �ndice do j� existente.
     for (int i=0; i<contador_vertice; i++)
     {
         if ( (fabs(x0-x[i])<1e-5) && (fabs(y_0-y[i])<1e-5) && (fabs(z0-z[i])<1e-5) )
         {
             v0 = i;
             vrepetido++;
             break;
         }
     }
     if (v0 == contador_vertice)
     {
        x[contador_vertice] = x0;
        y[contador_vertice] = y_0;
        z[contador_vertice] = z0;
     }
     // *** V�rtice novo 2 ******************************************
     v1 = contador_vertice+1-vrepetido;
     for (int i=0; i<contador_vertice; i++)
     {
         if ( (fabs(x1-x[i])<1e-5) && (fabs(y_1-y[i])<1e-5) && (fabs(z1-z[i])<1e-5) )
         {
             v1 = i;
             vrepetido++;
             break;
         }
     }
     if (v1 == contador_vertice+1-vrepetido)
     {
        x[contador_vertice+1-vrepetido] = x1;
        y[contador_vertice+1-vrepetido] = y_1;
        z[contador_vertice+1-vrepetido] = z1;
     }
     // *** V�rtice novo 3 ******************************************
     v2 = contador_vertice+2-vrepetido;
     for (int i=0; i<contador_vertice; i++)
     {
         if ( (fabs(x2-x[i])<1e-5) && (fabs(y_2-y[i])<1e-5) && (fabs(z2-z[i])<1e-5) )
         {
             v2 = i;
             vrepetido++;
             break;
         }
     }
     if (v2 == contador_vertice+2-vrepetido)
     {
        x[contador_vertice+2-vrepetido] = x2;
        y[contador_vertice+2-vrepetido] = y_2;
        z[contador_vertice+2-vrepetido] = z2;
     }
     // Incremento do contador de novos v�rtices.
     contador_vertice = contador_vertice + 3 - vrepetido;
}