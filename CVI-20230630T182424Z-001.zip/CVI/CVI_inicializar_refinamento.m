function [x, y, z] = CVI_inicializar_refinamento(xant, yant, zant)
{
    // ***************************
    // ** INICIO DO REFINAMENTO **
    // ***************************
    for (int i=0; i<vertice_nant; i++)
    {                    // Os 12 primeiros v�rtices s�o do icosaedral
        x[i] = xant[i];  // original, de n�vel 0. A malha de n�vel n
        y[i] = yant[i];  // alocar� nas primeiras posi��es os v�rtices
        z[i] = zant[i];  // da malha de n�vel n-1.
    }
    contador_vertice = vertice_nant; // A posi��o inicial dos novos v�rtices.
    contador_face    = 0; // As faces s�o sempre zeradas,
                          // pois as anteriores n�o s�o "aproveitadas".
}