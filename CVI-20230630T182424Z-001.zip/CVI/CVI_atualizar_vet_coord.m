function [xant, yant, zant] = CVI_atualizar_vet_coord
%
xant = x;
yant = y;
zant = z;