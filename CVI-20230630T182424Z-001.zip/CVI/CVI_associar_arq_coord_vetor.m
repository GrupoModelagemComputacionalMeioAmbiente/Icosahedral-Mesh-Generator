function [xant, yant, zant] = CVI_associar_arq_coord_vetor(n, m)
%Abertura do arquivo que contem as coordenadas x,y,z de n�vel 0.
nome = ['cico' int2str(n) '.txt');
coord = load(nome);

xant = coord(:,1);
yant = coord(:,2);
zant = coord(:,3);