function [phi, theta] = CVI_calcular_phi_theta(x, y, z)
{
     for (int i=0; i<vertice_n; i++)
     {
         phi[i] = acos(z[i]);
         
         if ( fabs(y[i]-0.0) < 1e-10 ) // Se y=0, ent�o o �ngulo entre a
         {                             // proje��o de R sobre o plano xy � 0.
            if ( (fabs(x[i]-0.0) < 1e-10) || (x[i] > 0) )
               theta[i] = 0.0;            
            else
                theta[i] = pi;
         }
         else
         {
            double r=0.0;
            r = sqrt(x[i]*x[i] + y[i]*y[i]);
            theta[i] = acos(x[i]/r);
         }
     }
}