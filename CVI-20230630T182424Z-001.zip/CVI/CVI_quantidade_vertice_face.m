function [vertice_n, vertice_nant, face_n, face_nant] = CVI_quantidade_vertice_face(n)
%
% QUANTIDADE DE V�RTICES DA MALHA DE N�VEL n E n-1.
vertice_n    = 10 * potencia(2,2* n   ) + 2;
vertice_nant = 10 * potencia(2,2*(n-1)) + 2;

% QUANTIDADE DE FACES DA MALHA DE N�VEL n E n-1.
face_n    = 20 * potencia(2,2* n   );
face_nant = 20 * potencia(2,2*(n-1));