function CVI_guarda_bissetor()
{
    string nome_arquivo, nome_generico;
    ofstream bis;

    nome_generico="bissetor";
    char num='z';
    if (n==1) num='0'; else if (n==2) num='1'; else if (n==3) num='2'; else if (n==4) num='3';
    else if (n==5) num='4'; else if (n==6) num='5'; else if (n==7) num='6';

    nome_arquivo = nome_generico + char(num)+".txt";
    bis.open (nome_arquivo.c_str());

    for (int i=0; i<face_nant; i++)
    {
        bis << b1[i][0] << " " << b1[i][1] << " " << b1[i][2] << " ";
        bis << b2[i][0] << " " << b2[i][1] << " " << b2[i][2] << " ";
        bis << b3[i][0] << " " << b3[i][1] << " " << b3[i][2] << endl;
    }
    bis.close();
}