function  faceant = CVI_atualizar_matriz_face
%
faceant = face;