function CVI_gerar_arquivos_entrada
{
    string nome_arquivo, nome_generico;
    // o primeiro arquivo guarda as coordenadas.
    ofstream coord;

    nome_generico="cico";
    char num='z';
    if (n==1) num='1'; else if (n==2) num='2'; else if (n==3) num='3';
    else if (n==4) num='4'; else if (n==5) num='5'; else if (n==6) num='6';

    nome_arquivo = nome_generico + char(num)+".txt";
    coord.open (nome_arquivo.c_str());

    for (int i=0; i<vertice_n; i++)
        coord << x[i] << " " << y[i] << " " << z[i] << endl;

    coord.close();

    // o segunda arquivo guarda as faces.
    string nome_arq, nome_g;
    ofstream faces;
    nome_g="fico";

    if (n==1) num='1'; else if (n==2) num='2'; else if (n==3) num='3';
    else if (n==4) num='4'; else if (n==5) num='5'; else if (n==6) num='6';

    nome_arq = nome_g + char(num)+".txt";
    faces.open (nome_arq.c_str());

    for (int i=0; i<face_n; i++)
        faces << face[i][0] << " " << face[i][1] << " " << face[i][2] << endl;

    faces.close();
}