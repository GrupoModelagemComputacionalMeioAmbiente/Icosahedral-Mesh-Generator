function faceant = CVI_associar_arq_face_matriz
%
faceant = load fico0.txt;