%
n = 0;                n_maximo = 7;         vertice_n = 0; 
vertice_nant = 0;     face_n = 0;           face_nant = 0;
contador_vertice = 0; contador_face = 0;
v0 = 0;               v1 = 0;               v2 = 0;        vrepetido = 0;
d1 = 0.0;             d2 = 0.0;             d3 = 0.0;
x0 = 0.0;             x1 = 0.0;             x2 = 0.0;      
y_0 = 0.0;            y_1 = 0.0;            y_2 = 0.0;
z0 = 0.0;             z1 = 0.0;             z2 = 0.0;
%**************************************************************************
%** n                - contador do n�vel da malha.                       **
%** n_maximo         - o maior valor (nivel) que n pode assumir.         **
%** vertice_n        - quantidade de vertices da malha de nivel n.       **
%** vertice_nant     - quantidade de vertices da malha de nivel n-1.     **
%** face_n           - quantidade de faces da malha de nivel n.          **
%** face_nant        - quantidade de faces da malha de nivel n-1.        **
%** contador_face    - responsavel pelo controle das faces novas.        **
%** contador_vertice - responsavel pelo controle dos vertice novos.      **
%** v0, v1, v2 - controla a numera��o dos novos v�rtices.                **
%** vrepetido  - verifica a unicidade do novo vertice.                   **
%** d1, d2, d3 - tamanho das arestas das faces.                          **
%** x0, x_1, x2, y0, y_1, y2, z0, z_1, z2 - coordenadas dos bissetores.  **
%************************************************************************** 
%**************************************************************************
%** x, y, z          - coordenadas da malha de n�vel n.                  **
%** xant, yant, zant - coordenadas da malha de n�vel n-1.                ** 
%** face, faceant    - faces de nivel n e n-1.                           **
%**************************************************************************

[xant, yant, zant] = CVI_associar_arq_coord_vetor(0,12);
faceant            = CVI_associar_arq_face_matriz;

b1 = zeros(20,3);   b2 = zeros(20,3);   b3 = zeros(20,3);

for n = 1:n_maximo
    fprintf('Nivel %g\n',n);

    if (n>1)
        clear xant yant zant
        [xant, yant, zant] = CVI_atualizar_vet_coord;

        clear faceant 
        faceant = CVI_atualizar_matriz_face;
        
        clear b1 b2 b3
        b1 = zeros(face_n,3);
        b2 = zeros(face_n,3);
        b3 = zeros(face_n,3);
        
        clear face x y z phi theta
    end

    [vertice_n, vertice_nant, face_n, face_nant] = CVI_quantidade_vertice_face(n);

    montar_inicializar_matriz_face_n(face_n);
    inicializar_refinamento();

    for (int k=0; k<face_nant; k++) // k ir� contar as faces do n�vel
                                    // anterior para gerar as novas.
        cout << "k = " << k << endl;
        calculo_novos_vertices(k);
        calculo_novas_faces(k);
    end
    
    calcular_phi_theta();
    guarda_coord_esferica();
            
    guarda_bissetor();
    gerar_arquivo_vtk();
    gerar_arquivos_entrada();
            
            
end

clear

%**************************************************************************
%* n            => n�vel do refinamento.                                  *
%* n_maximo     => n�vel m�ximo de refinamento.                           *
%* vertice_n    => qtd de vert. de n�vel n.                               *
%* vertice_nant => qtd de vert de n�vel n-1.                              *
%**************************************************************************