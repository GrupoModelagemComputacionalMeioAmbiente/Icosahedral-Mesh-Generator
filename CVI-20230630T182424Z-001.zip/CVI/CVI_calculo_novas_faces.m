function face = CVI_calculo_novas_faces(int k)
{
     // Contru��o das novas faces.
     // ****** Face nova 0 ******************************************
     face[contador_face][0] = faceant[k][0];
     face[contador_face][1] = v0;
     face[contador_face][2] = v2;
     // ****** Face nova 1 ******************************************
     face[contador_face+1][0] = v0;
     face[contador_face+1][1] = faceant[k][1];
     face[contador_face+1][2] = v1;
     // ****** Face nova 2 ******************************************
     face[contador_face+2][0] = v0;
     face[contador_face+2][1] = v1;
     face[contador_face+2][2] = v2;
     // ****** Face nova 3 ******************************************
     face[contador_face+3][0] = v2;
     face[contador_face+3][1] = v1;
     face[contador_face+3][2] = faceant[k][2];
     // Incremento do contador de novas faces.
     contador_face = contador_face + 4;
}